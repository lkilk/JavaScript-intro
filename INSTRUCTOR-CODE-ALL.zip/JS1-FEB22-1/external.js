function sayHi(){
    alert('Hi from an external script');
}
